# Sales Management System (2026 rebuild)

Internal web app for Mr. Robinson's book retail business — Sales Orders, Purchase Orders,
vendors, item master, cash ledger, low-stock alerts, and reports.

Built per `06-最终定型稿.md` (frozen Product Shipping Brief, v2.6) and `PRD文档.md`.

## Tech stack

- **Backend**: Node.js + Express
- **Database**: SQLite (via Node's built-in `node:sqlite` — no native module compilation needed)
- **Frontend**: React + TypeScript + Tailwind CSS v4, styled with **coss.com/ui**
  (Cal.com's open-source design system, built on Base UI primitives, installed via the shadcn CLI)
  — bundled with Vite. This replaced the original plain HTML/vanilla JS frontend (D003).

## Requirements

- Node.js **22.5+** (for built-in `node:sqlite`). Check with `node -v`.
- (Only if you want to rebuild the frontend) Node 18+ is enough to run `npm run build` inside `frontend-src/`.

## Running it (pre-built, recommended)

The `public/` folder already contains the built frontend — you don't need to build anything to run the app.

```bash
npm install
node server.js
```

Then open **http://localhost:3000** in your browser.

The database file `db/data.sqlite` is created automatically on first run, seeded with:

| Role  | Username | Password  |
|-------|----------|-----------|
| Admin | admin    | admin123  |
| Staff | staff1   | staff123  |

Delete `db/data.sqlite` and restart to reset to a fresh seeded state.

## Modifying the frontend

The React source lives in `frontend-src/`. To make changes and rebuild:

```bash
cd frontend-src
npm install
npm run dev      # local dev server at http://localhost:5173, proxies /api and /print to :3000
# ...make your changes...
npm run build     # outputs to frontend-src/dist
```

Then copy the build output into the backend's static folder so `node server.js` serves it:

```bash
rm -rf ../public/*
cp -r dist/* ../public/
```

(Run the backend — `node server.js` — in a separate terminal at the same time as `npm run dev`
if you want live API data while developing the UI.)

## What's implemented (see PRD文档.md for full FR/AC list)

- Login + roles (Admin / Staff)
- Sales Orders: multi-book line items, can be created with insufficient stock (stays Pending),
  Confirm gated on stock sufficiency, Deliver, Pay (auto cash-in), print Delivery Order (post-Confirm)
  and Invoice (post-Paid)
- Purchase Orders: multi-book line items, Confirm, print Purchase Order (post-Confirm),
  GRN/Goods Received (auto stock-in), Pay (auto cash-out)
- Vendors (Admin + Staff can create; **names must be unique**, D002)
- Item Master / books (Admin-only create **and edit**; Staff view-only)
- Dashboard: low-stock alert (stock_qty <= safety_stock_qty)
- Cash Ledger: running balance of all cash-in/cash-out entries (Admin only)
- Reports: daily/monthly/yearly sales totals, Top 10 books by qty sold, **with a month picker** (Admin only)
- User Management (Admin-only account creation **and password reset**, F09-02)

## Known gaps (documented, not oversights)

- No PDF export — printable docs (`/print/...` routes, unchanged from the original build) use the
  browser's native print (Ctrl/Cmd+P).
- No HTTPS enforced, no audit log, no automated database backup — see PRD §6.2–6.3 and §8 for the
  full risk writeup and mitigations.
- Session store is in-memory — restarting the server logs everyone out (fine for a single-instance
  internal tool). Resetting a password does **not** force-expire that user's existing session
  (documented as a deliberate MVP simplification in PRD §5.2.2 / §8.6).
