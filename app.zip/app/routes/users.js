const express = require('express');
const { db, hashPassword } = require('../db/db');
const { requireAdmin } = require('./middleware');
const crypto = require('crypto');

const router = express.Router();

router.get('/', requireAdmin, (req, res) => {
  const users = db
    .prepare('SELECT id, name, username, role, created_at FROM users ORDER BY name')
    .all();
  res.json({ users });
});

router.post('/', requireAdmin, (req, res) => {
  const { name, username, password, role } = req.body;
  if (!name || !username || !password || !role) {
    return res.status(400).json({ error: 'name, username, password, role are required' });
  }
  if (!['Admin', 'Staff'].includes(role)) {
    return res.status(400).json({ error: 'role must be Admin or Staff' });
  }
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) return res.status(409).json({ error: 'Username already exists' });

  const salt = crypto.randomBytes(16).toString('hex');
  const hash = hashPassword(password, salt);
  const result = db
    .prepare(
      'INSERT INTO users (name, username, password_hash, salt, role) VALUES (?, ?, ?, ?, ?)'
    )
    .run(name, username, hash, salt, role);
  res.json({ id: Number(result.lastInsertRowid) });
});

// F09-02: Admin resets any user's password. No old-password check (Admin acting on
// the user's behalf, not self-service). Does not force-expire existing sessions (see
// PRD §5.2.2 business rule 5 / §8.6).
router.post('/:id/reset-password', requireAdmin, (req, res) => {
  const { password } = req.body;
  if (!password || password.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters' });
  }
  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const salt = crypto.randomBytes(16).toString('hex');
  const hash = hashPassword(password, salt);
  db.prepare('UPDATE users SET password_hash = ?, salt = ? WHERE id = ?').run(hash, salt, req.params.id);
  res.json({ ok: true });
});

module.exports = router;
