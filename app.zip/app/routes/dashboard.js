const express = require('express');
const { db } = require('../db/db');
const { requireLogin } = require('./middleware');

const router = express.Router();

router.get('/', requireLogin, (req, res) => {
  const lowStock = db
    .prepare('SELECT * FROM books WHERE stock_qty <= safety_stock_qty ORDER BY (stock_qty - safety_stock_qty) ASC')
    .all();
  res.json({ lowStock });
});

module.exports = router;
