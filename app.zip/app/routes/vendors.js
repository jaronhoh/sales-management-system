const express = require('express');
const { db } = require('../db/db');
const { requireLogin } = require('./middleware');

const router = express.Router();

router.get('/', requireLogin, (req, res) => {
  const vendors = db.prepare('SELECT * FROM vendors ORDER BY name').all();
  res.json({ vendors });
});

// Both Admin and Staff can create vendors (FR-18)
router.post('/', requireLogin, (req, res) => {
  const { name, contact_info } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required' });
  const existing = db.prepare('SELECT id FROM vendors WHERE name = ?').get(name);
  if (existing) return res.status(409).json({ error: 'Vendor name already exists' });
  const result = db
    .prepare('INSERT INTO vendors (name, contact_info) VALUES (?, ?)')
    .run(name, contact_info || '');
  res.json({ id: Number(result.lastInsertRowid) });
});

module.exports = router;
