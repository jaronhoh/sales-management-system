const express = require('express');
const { db } = require('../db/db');
const { requireAdmin } = require('./middleware');

const router = express.Router();

router.get('/', requireAdmin, (req, res) => {
  const entries = db.prepare('SELECT * FROM cash_ledger ORDER BY created_at ASC, id ASC').all();
  let balance = 0;
  const withBalance = entries.map((e) => {
    balance += e.type === 'in' ? e.amount : -e.amount;
    return { ...e, running_balance: balance };
  });
  res.json({ entries: withBalance.reverse(), balance });
});

module.exports = router;
