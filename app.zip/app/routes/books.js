const express = require('express');
const { db } = require('../db/db');
const { requireLogin, requireAdmin } = require('./middleware');

const router = express.Router();

// List all books (Admin + Staff, view-only for Staff)
router.get('/', requireLogin, (req, res) => {
  const books = db.prepare('SELECT * FROM books ORDER BY title').all();
  res.json({ books });
});

// Create book - Admin only (FR-20 / FR-21)
router.post('/', requireAdmin, (req, res) => {
  const { title, price, cost_price, stock_qty, safety_stock_qty } = req.body;
  if (!title || price == null) {
    return res.status(400).json({ error: 'title and price are required' });
  }
  const result = db
    .prepare(
      'INSERT INTO books (title, price, cost_price, stock_qty, safety_stock_qty) VALUES (?, ?, ?, ?, ?)'
    )
    .run(title, price, cost_price || 0, stock_qty || 0, safety_stock_qty || 0);
  res.json({ id: Number(result.lastInsertRowid) });
});

// Edit book - Admin only
router.put('/:id', requireAdmin, (req, res) => {
  const { title, price, cost_price, stock_qty, safety_stock_qty } = req.body;
  db.prepare(
    'UPDATE books SET title = ?, price = ?, cost_price = ?, stock_qty = ?, safety_stock_qty = ? WHERE id = ?'
  ).run(title, price, cost_price, stock_qty, safety_stock_qty, req.params.id);
  res.json({ ok: true });
});

module.exports = router;
