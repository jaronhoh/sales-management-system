const express = require('express');
const { db } = require('../db/db');
const { requireLogin } = require('./middleware');

const router = express.Router();

function docHtml({ title, docNumber, docDate, partyLabel, partyName, items, totalLabel, total, note }) {
  const rows = items
    .map(
      (it, i) => `
      <tr>
        <td>${i + 1}</td>
        <td>${it.title}</td>
        <td style="text-align:right">${it.qty}</td>
        <td style="text-align:right">${it.unit.toFixed(2)}</td>
        <td style="text-align:right">${(it.qty * it.unit).toFixed(2)}</td>
      </tr>`
    )
    .join('');

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>${title} #${docNumber}</title>
<style>
  @page { size: A4; margin: 20mm; }
  body { font-family: Arial, sans-serif; color: #222; }
  h1 { font-size: 22px; margin-bottom: 4px; }
  .meta { margin-bottom: 24px; color: #555; }
  table { width: 100%; border-collapse: collapse; margin-top: 16px; }
  th, td { border: 1px solid #ccc; padding: 8px; font-size: 13px; }
  th { background: #f2f2f2; text-align: left; }
  .totals { margin-top: 16px; text-align: right; font-size: 15px; font-weight: bold; }
  .print-btn { margin: 16px 0; }
  @media print { .print-btn { display: none; } }
</style>
</head>
<body>
  <h1>${title}</h1>
  <div class="meta">
    <div><strong>${title} No.</strong> ${docNumber}</div>
    <div><strong>Date:</strong> ${docDate}</div>
    <div><strong>${partyLabel}:</strong> ${partyName}</div>
  </div>
  <table>
    <thead><tr><th>#</th><th>Book</th><th>Qty</th><th>Unit</th><th>Line total</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="totals">${totalLabel}: ${total.toFixed(2)}</div>
  ${note ? `<p style="margin-top:24px;color:#777;font-size:12px;">${note}</p>` : ''}
  <div class="print-btn"><button onclick="window.print()">Print</button></div>
</body>
</html>`;
}

// Delivery Order - printable only once Sales Order status >= Confirmed (FR-7)
router.get('/sales-order/:id/delivery-order', requireLogin, (req, res) => {
  const order = db.prepare('SELECT * FROM sales_orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).send('Not found');
  if (order.status === 'Pending') {
    return res.status(403).send('Delivery Order not available: order must be Confirmed first.');
  }
  const items = db
    .prepare(
      `SELECT soi.qty, soi.unit_price AS unit, b.title
       FROM sales_order_items soi JOIN books b ON b.id = soi.book_id
       WHERE soi.sales_order_id = ?`
    )
    .all(order.id);
  const total = items.reduce((s, it) => s + it.qty * it.unit, 0);
  res.send(
    docHtml({
      title: 'Delivery Order',
      docNumber: order.id,
      docDate: order.confirmed_at || order.created_at,
      partyLabel: 'Salesperson',
      partyName: order.salesperson_name,
      items,
      totalLabel: 'Total',
      total,
    })
  );
});

// Invoice - printable only once Sales Order status = Paid (FR-10)
router.get('/sales-order/:id/invoice', requireLogin, (req, res) => {
  const order = db.prepare('SELECT * FROM sales_orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).send('Not found');
  if (order.status !== 'Paid') {
    return res.status(403).send('Invoice not available: order must be Paid first.');
  }
  const items = db
    .prepare(
      `SELECT soi.qty, soi.unit_price AS unit, b.title
       FROM sales_order_items soi JOIN books b ON b.id = soi.book_id
       WHERE soi.sales_order_id = ?`
    )
    .all(order.id);
  const total = items.reduce((s, it) => s + it.qty * it.unit, 0);
  res.send(
    docHtml({
      title: 'Invoice',
      docNumber: order.id,
      docDate: order.paid_at,
      partyLabel: 'Salesperson',
      partyName: order.salesperson_name,
      items,
      totalLabel: 'Total Paid',
      total,
      note: 'Paid in full.',
    })
  );
});

// Purchase Order document - printable only once status >= Confirmed (FR-14)
router.get('/purchase-order/:id', requireLogin, (req, res) => {
  const order = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).send('Not found');
  if (order.status === 'Pending') {
    return res.status(403).send('Purchase Order document not available: order must be Confirmed first.');
  }
  const vendor = db.prepare('SELECT * FROM vendors WHERE id = ?').get(order.vendor_id);
  const items = db
    .prepare(
      `SELECT poi.qty, poi.unit_cost AS unit, b.title
       FROM purchase_order_items poi JOIN books b ON b.id = poi.book_id
       WHERE poi.purchase_order_id = ?`
    )
    .all(order.id);
  const total = items.reduce((s, it) => s + it.qty * it.unit, 0);
  res.send(
    docHtml({
      title: 'Purchase Order',
      docNumber: order.id,
      docDate: order.confirmed_at || order.created_at,
      partyLabel: 'Vendor',
      partyName: vendor ? vendor.name : `#${order.vendor_id}`,
      items,
      totalLabel: 'Total',
      total,
    })
  );
});

module.exports = router;
