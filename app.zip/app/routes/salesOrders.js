const express = require('express');
const { db } = require('../db/db');
const { requireLogin } = require('./middleware');

const router = express.Router();

function loadOrderWithItems(orderId) {
  const order = db.prepare('SELECT * FROM sales_orders WHERE id = ?').get(orderId);
  if (!order) return null;
  const items = db
    .prepare(
      `SELECT soi.*, b.title, b.stock_qty AS current_stock
       FROM sales_order_items soi JOIN books b ON b.id = soi.book_id
       WHERE soi.sales_order_id = ?`
    )
    .all(orderId);
  return { ...order, items };
}

// List (FR-11: searchable/filterable by status, date, salesperson, book)
router.get('/', requireLogin, (req, res) => {
  const { status, salesperson, book_id } = req.query;
  let sql = `SELECT DISTINCT so.* FROM sales_orders so`;
  const conditions = [];
  const params = [];
  if (book_id) {
    sql += ` JOIN sales_order_items soi ON soi.sales_order_id = so.id`;
    conditions.push('soi.book_id = ?');
    params.push(book_id);
  }
  if (status) {
    conditions.push('so.status = ?');
    params.push(status);
  }
  if (salesperson) {
    conditions.push('so.salesperson_name LIKE ?');
    params.push(`%${salesperson}%`);
  }
  if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ');
  sql += ' ORDER BY so.created_at DESC';
  const orders = db.prepare(sql).all(...params);
  res.json({ orders });
});

router.get('/:id', requireLogin, (req, res) => {
  const order = loadOrderWithItems(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  res.json({ order });
});

// Create (FR-4, FR-5: allowed even with insufficient stock, status Pending)
router.post('/', requireLogin, (req, res) => {
  const { salesperson_name, items } = req.body;
  if (!salesperson_name || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'salesperson_name and at least one item are required' });
  }

  const result = db
    .prepare('INSERT INTO sales_orders (created_by, salesperson_name, status) VALUES (?, ?, ?)')
    .run(req.session.user.id, salesperson_name, 'Pending');
  const orderId = Number(result.lastInsertRowid);

  const insertItem = db.prepare(
    'INSERT INTO sales_order_items (sales_order_id, book_id, qty, unit_price) VALUES (?, ?, ?, ?)'
  );
  for (const item of items) {
    const book = db.prepare('SELECT * FROM books WHERE id = ?').get(item.book_id);
    if (!book) return res.status(400).json({ error: `Book ${item.book_id} not found` });
    insertItem.run(orderId, item.book_id, item.qty, item.unit_price ?? book.price);
  }

  res.json({ id: orderId });
});

// Confirm (FR-6: gated on stock sufficiency)
router.post('/:id/confirm', requireLogin, (req, res) => {
  const order = loadOrderWithItems(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  if (order.status !== 'Pending') {
    return res.status(400).json({ error: `Cannot confirm order in status ${order.status}` });
  }

  const shortfalls = order.items
    .filter((it) => it.qty > it.current_stock)
    .map((it) => ({
      book_id: it.book_id,
      title: it.title,
      needed: it.qty,
      available: it.current_stock,
      shortfall: it.qty - it.current_stock,
    }));

  if (shortfalls.length > 0) {
    return res.status(409).json({
      error: 'Insufficient stock - Confirm blocked. Raise a Purchase Order for the shortfall.',
      shortfalls,
    });
  }

  db.prepare(
    "UPDATE sales_orders SET status = 'Confirmed', confirmed_at = strftime('%Y-%m-%d %H:%M:%S','now') WHERE id = ?"
  ).run(order.id);
  res.json({ ok: true, status: 'Confirmed' });
});

// Mark Delivered (FR-8)
router.post('/:id/deliver', requireLogin, (req, res) => {
  const order = db.prepare('SELECT * FROM sales_orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  if (order.status !== 'Confirmed') {
    return res.status(400).json({ error: `Order must be Confirmed before Delivered (currently ${order.status})` });
  }
  db.prepare(
    "UPDATE sales_orders SET status = 'Delivered', delivered_at = strftime('%Y-%m-%d %H:%M:%S','now') WHERE id = ?"
  ).run(order.id);
  res.json({ ok: true, status: 'Delivered' });
});

// Mark Paid (FR-9: triggers cash-in ledger entry)
router.post('/:id/pay', requireLogin, (req, res) => {
  const order = loadOrderWithItems(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  if (order.status !== 'Delivered') {
    return res.status(400).json({ error: `Order must be Delivered before Paid (currently ${order.status})` });
  }
  const total = order.items.reduce((sum, it) => sum + it.qty * it.unit_price, 0);

  db.prepare(
    "UPDATE sales_orders SET status = 'Paid', paid_at = strftime('%Y-%m-%d %H:%M:%S','now') WHERE id = ?"
  ).run(order.id);
  db.prepare("INSERT INTO cash_ledger (type, amount, source) VALUES ('in', ?, ?)").run(
    total,
    `SalesOrder #${order.id}`
  );
  res.json({ ok: true, status: 'Paid', amount: total });
});

// Cancel (only from Pending or Confirmed — blocked once Delivered/Paid, since stock/cash impact has occurred)
router.post('/:id/cancel', requireLogin, (req, res) => {
  const order = db.prepare('SELECT * FROM sales_orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  if (!['Pending', 'Confirmed'].includes(order.status)) {
    return res.status(400).json({
      error: `Cannot cancel an order in status ${order.status} (only Pending or Confirmed orders can be cancelled)`,
    });
  }
  db.prepare(
    "UPDATE sales_orders SET status = 'Cancelled', cancelled_at = strftime('%Y-%m-%d %H:%M:%S','now') WHERE id = ?"
  ).run(order.id);
  res.json({ ok: true, status: 'Cancelled' });
});

module.exports = router;
