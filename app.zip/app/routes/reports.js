const express = require('express');
const { db } = require('../db/db');
const { requireAdmin } = require('./middleware');

const router = express.Router();

// Daily / monthly / yearly sales totals, based on Paid sales orders (FR-26)
router.get('/sales', requireAdmin, (req, res) => {
  const daily = db
    .prepare(
      `SELECT substr(so.paid_at, 1, 10) AS period, SUM(soi.qty * soi.unit_price) AS total
       FROM sales_orders so JOIN sales_order_items soi ON soi.sales_order_id = so.id
       WHERE so.status = 'Paid'
       GROUP BY period ORDER BY period DESC`
    )
    .all();

  const monthly = db
    .prepare(
      `SELECT substr(so.paid_at, 1, 7) AS period, SUM(soi.qty * soi.unit_price) AS total
       FROM sales_orders so JOIN sales_order_items soi ON soi.sales_order_id = so.id
       WHERE so.status = 'Paid'
       GROUP BY period ORDER BY period DESC`
    )
    .all();

  const yearly = db
    .prepare(
      `SELECT substr(so.paid_at, 1, 4) AS period, SUM(soi.qty * soi.unit_price) AS total
       FROM sales_orders so JOIN sales_order_items soi ON soi.sales_order_id = so.id
       WHERE so.status = 'Paid'
       GROUP BY period ORDER BY period DESC`
    )
    .all();

  res.json({ daily, monthly, yearly });
});

// Top 10 books by quantity sold this month (FR-27)
router.get('/top-books', requireAdmin, (req, res) => {
  const month = req.query.month || new Date().toISOString().slice(0, 7); // YYYY-MM
  const topBooks = db
    .prepare(
      `SELECT b.id, b.title, SUM(soi.qty) AS qty_sold, SUM(soi.qty * soi.unit_price) AS revenue
       FROM sales_order_items soi
       JOIN sales_orders so ON so.id = soi.sales_order_id
       JOIN books b ON b.id = soi.book_id
       WHERE so.status = 'Paid' AND substr(so.paid_at, 1, 7) = ?
       GROUP BY b.id ORDER BY qty_sold DESC LIMIT 10`
    )
    .all(month);
  res.json({ month, topBooks });
});

module.exports = router;
