const express = require('express');
const { db } = require('../db/db');
const { requireLogin } = require('./middleware');

const router = express.Router();

function loadOrderWithItems(orderId) {
  const order = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(orderId);
  if (!order) return null;
  const items = db
    .prepare(
      `SELECT poi.*, b.title
       FROM purchase_order_items poi JOIN books b ON b.id = poi.book_id
       WHERE poi.purchase_order_id = ?`
    )
    .all(orderId);
  const vendor = db.prepare('SELECT * FROM vendors WHERE id = ?').get(order.vendor_id);
  return { ...order, items, vendor };
}

// List (FR-17: filterable by status, date, vendor)
router.get('/', requireLogin, (req, res) => {
  const { status, vendor_id } = req.query;
  let sql = 'SELECT * FROM purchase_orders';
  const conditions = [];
  const params = [];
  if (status) {
    conditions.push('status = ?');
    params.push(status);
  }
  if (vendor_id) {
    conditions.push('vendor_id = ?');
    params.push(vendor_id);
  }
  if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ');
  sql += ' ORDER BY created_at DESC';
  const orders = db.prepare(sql).all(...params);
  res.json({ orders });
});

router.get('/:id', requireLogin, (req, res) => {
  const order = loadOrderWithItems(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  res.json({ order });
});

// Create (FR-12)
router.post('/', requireLogin, (req, res) => {
  const { vendor_id, items } = req.body;
  if (!vendor_id || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'vendor_id and at least one item are required' });
  }
  const vendor = db.prepare('SELECT * FROM vendors WHERE id = ?').get(vendor_id);
  if (!vendor) return res.status(400).json({ error: 'Vendor not found' });

  const result = db
    .prepare('INSERT INTO purchase_orders (created_by, vendor_id, status) VALUES (?, ?, ?)')
    .run(req.session.user.id, vendor_id, 'Pending');
  const orderId = Number(result.lastInsertRowid);

  const insertItem = db.prepare(
    'INSERT INTO purchase_order_items (purchase_order_id, book_id, qty, unit_cost) VALUES (?, ?, ?, ?)'
  );
  for (const item of items) {
    const book = db.prepare('SELECT * FROM books WHERE id = ?').get(item.book_id);
    if (!book) return res.status(400).json({ error: `Book ${item.book_id} not found` });
    insertItem.run(orderId, item.book_id, item.qty, item.unit_cost ?? book.price);
  }

  res.json({ id: orderId });
});

// Confirm (FR-13: no stock precondition for PO)
router.post('/:id/confirm', requireLogin, (req, res) => {
  const order = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  if (order.status !== 'Pending') {
    return res.status(400).json({ error: `Cannot confirm order in status ${order.status}` });
  }
  db.prepare(
    "UPDATE purchase_orders SET status = 'Confirmed', confirmed_at = strftime('%Y-%m-%d %H:%M:%S','now') WHERE id = ?"
  ).run(order.id);
  res.json({ ok: true, status: 'Confirmed' });
});

// Mark GRN - Goods Received (FR-15: increases stock_qty for each line item — the only stock-in mechanism)
router.post('/:id/grn', requireLogin, (req, res) => {
  const order = loadOrderWithItems(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  if (order.status !== 'Confirmed') {
    return res.status(400).json({ error: `Order must be Confirmed before GRN (currently ${order.status})` });
  }

  const updateStock = db.prepare('UPDATE books SET stock_qty = stock_qty + ? WHERE id = ?');
  for (const item of order.items) {
    updateStock.run(item.qty, item.book_id);
  }
  db.prepare(
    "UPDATE purchase_orders SET status = 'GRN', grn_at = strftime('%Y-%m-%d %H:%M:%S','now') WHERE id = ?"
  ).run(order.id);
  res.json({ ok: true, status: 'GRN' });
});

// Mark Paid (FR-16: triggers cash-out ledger entry)
router.post('/:id/pay', requireLogin, (req, res) => {
  const order = loadOrderWithItems(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  if (order.status !== 'GRN') {
    return res.status(400).json({ error: `Order must be GRN (goods received) before Paid (currently ${order.status})` });
  }
  const total = order.items.reduce((sum, it) => sum + it.qty * it.unit_cost, 0);

  db.prepare(
    "UPDATE purchase_orders SET status = 'Paid', paid_at = strftime('%Y-%m-%d %H:%M:%S','now') WHERE id = ?"
  ).run(order.id);
  db.prepare("INSERT INTO cash_ledger (type, amount, source) VALUES ('out', ?, ?)").run(
    total,
    `PurchaseOrder #${order.id}`
  );
  res.json({ ok: true, status: 'Paid', amount: total });
});

// Cancel (only from Pending or Confirmed — blocked once GRN/Paid, since stock/cash impact has occurred)
router.post('/:id/cancel', requireLogin, (req, res) => {
  const order = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  if (!['Pending', 'Confirmed'].includes(order.status)) {
    return res.status(400).json({
      error: `Cannot cancel an order in status ${order.status} (only Pending or Confirmed orders can be cancelled)`,
    });
  }
  db.prepare(
    "UPDATE purchase_orders SET status = 'Cancelled', cancelled_at = strftime('%Y-%m-%d %H:%M:%S','now') WHERE id = ?"
  ).run(order.id);
  res.json({ ok: true, status: 'Cancelled' });
});

module.exports = router;
