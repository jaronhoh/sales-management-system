# Installation & Startup Guide

This guide covers getting the **Sales Management System** running on your computer, starting it, and stopping it. Written for Windows, with Mac/Linux notes where they differ.

---

## 1. Requirements

- **Node.js 22.5 or newer** (the app uses Node's built-in `node:sqlite` module, added in 22.5 — no separate database software needed).
- The `sales-management-system.zip` file (contains the app).

Check if Node is already installed:
```
node -v
```
If that prints `v22.5.0` or higher, skip to Step 3. If it errors, or shows an older version, do Step 2.

---

## 2. Install Node.js (Windows)

**Option A — official installer (simplest)**
1. Go to https://nodejs.org
2. Download the Windows installer (`.msi`) — pick a 22.x version (LTS or newer), **not** below 22.5
3. Run the installer, accept the defaults
4. Open a **new** Command Prompt or PowerShell window (must be new, so it picks up the updated PATH)
5. Confirm:
   ```
   node -v
   ```

**Option B — nvm-windows (if you want to switch Node versions later)**
1. Install nvm-windows: https://github.com/coreybutler/nvm-windows/releases (`nvm-setup.exe`)
2. In a new terminal:
   ```
   nvm install 22.12.0
   nvm use 22.12.0
   node -v
   ```

*(Mac: `brew install node@22` or download from nodejs.org. Linux: use your distro's package manager or nodejs.org's binaries — just make sure the version is 22.5+.)*

---

## 3. Unzip and install dependencies

1. Right-click `sales-management-system.zip` → **Extract All...** → choose a folder (e.g. `Documents\sales-management-system`)
2. Open a terminal **in that extracted folder**:
   - Windows: open the folder in File Explorer, click the address bar, type `cmd`, press Enter
   - Or: `cd` into it manually, e.g. `cd Documents\sales-management-system`
3. Install dependencies:
   ```
   npm install
   ```
   This downloads Express and express-session into a `node_modules` folder (only needs to be done once, or again if you delete `node_modules`).

---

## 4. Start the app

In the same terminal, in the project folder:
```
node server.js
```

You should see:
```
Database initialized with seed data.
  Admin login:  admin / admin123
  Staff login:  staff1 / staff123
Sales Management System running at http://localhost:3000
```

(The "Database initialized" lines only appear the **first** time you run it — that's when `db/data.sqlite` gets created and seeded.)

---

## 5. Open it in your browser

Go to:
```
http://localhost:3000
```

Log in with one of the seed accounts:

| Role  | Username | Password  |
|-------|----------|-----------|
| Admin | admin    | admin123  |
| Staff | staff1   | staff123  |

Leave the terminal window open while you use the app — closing it stops the server.

---

## 6. Stop the app

Go to the terminal window where it's running and press:
```
Ctrl + C
```

This immediately stops the server. Since login sessions are kept in memory, everyone will need to log in again next time you start it.

**If you closed the terminal without stopping it first** (so it's still running in the background):

- **Windows:**
  ```
  netstat -ano | findstr :3000
  ```
  Note the PID (last column), then:
  ```
  taskkill /PID <that_pid> /F
  ```
- **Mac/Linux:**
  ```
  lsof -i :3000
  kill -9 <PID>
  ```

---

## 7. Starting it again later

Just repeat Step 4 (`node server.js`) from the project folder — no need to run `npm install` again unless you deleted `node_modules`. Your data (orders, books, ledger, etc.) is saved in `db/data.sqlite` and will still be there.

---

## 8. Resetting to a clean slate

If you want to wipe all data and start fresh with just the seed accounts/books:
1. Stop the server (Step 6)
2. Delete the file `db/data.sqlite`
3. Start it again (Step 4) — it will recreate and reseed the database

---

## 9. Troubleshooting

| Problem | Likely cause / fix |
|---|---|
| `node: command not found` (or similar) | Node isn't installed, or you need a new terminal window after installing it |
| Error mentioning `node:sqlite` or `DatabaseSync` | Your Node version is below 22.5 — check with `node -v` and upgrade |
| `Error: listen EADDRINUSE: address already in use :::3000` | Something (maybe a previous run of this app) is already using port 3000 — see Step 6 to find and stop it, or close that other terminal |
| Blank page / can't reach `localhost:3000` | Make sure the terminal still shows "Sales Management System running..." — if it stopped or errored, scroll up in the terminal to see why |
| Forgot a password / locked out | Stop the server, delete `db/data.sqlite`, restart — this resets to the seed accounts (you'll lose all data, so only do this if you don't need to keep anything) |
| `npm install` fails | Check your internet connection; corporate networks/proxies sometimes block npm — try again on a different network if possible |
